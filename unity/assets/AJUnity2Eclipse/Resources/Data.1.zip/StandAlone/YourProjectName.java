package {PackageName};

import android.os.Bundle;
import android.util.Log;

import com.unity3d.player.UnityPlayerActivity;

/**
 * This class extends the UnityPlayerActivity. You can find more information about writing
 * Android plugins in the official unity docs.
 *
 * @see "http://docs.unity3d.com/Documentation/Manual/PluginsForAndroid.html"
 */
public class {ProductName} extends UnityPlayerActivity
{
	/**
	 * Called when the activity is starting
	 *
	 * @see "http://developer.android.com/reference/android/app/Activity.html#onCreate(android.os.Bundle)" 
	 */
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
	}

	/**
	 * Called when the activity has detected the user's press of the back key.
	 * @see "http://developer.android.com/reference/android/app/Activity.html#onBackPressed()"
	 */
	public void onBackPressed()
	{
		// Explicitly ignore the back-button event
		// super.onBackPressed();
	}
}
