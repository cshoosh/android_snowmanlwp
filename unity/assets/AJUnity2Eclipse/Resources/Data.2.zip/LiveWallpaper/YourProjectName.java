package {PackageName};

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import com.appjigger.eclipse.*;

public class {ProductName} extends WallpaperService
{
	/**
	 * Called once to initialize the engine.
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onCreate(android.view.SurfaceHolder)"
	 */
    public void onLWPCreate(SurfaceHolder holder)
    {

    }

    /**
     * Called right before the engine is going away.
     * 
     * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onDestroy()"
     */
    public void onLWPDestroy()
    {
 
    }
	
    /**
     * Called when an application has changed the desired virtual size of the wallpaper.
     * 
     * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onDesiredSizeChanged(int,%20int)"
     */
	public void onLWPDesiredSizeChanged(int desiredWidth, int desiredHeight)
	{

	}

	/**
	 * Called to inform you of the wallpaper's offsets changing within its contain, corresponding to the container's call to WallpaperManager.setWallpaperOffsets().
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onOffsetsChanged(float,%20float,%20float,%20float,%20int,%20int)"
	 */
	public void onLWPOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset)
	{

	}

	/**
	 * Called as the user performs touch-screen interaction with the window that is currently showing this wallpaper.
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onTouchEvent(android.view.MotionEvent)"
	 */
	public void onLWPTouchEvent(MotionEvent event)
	{

	}

	/**
	 * Called to inform you of the wallpaper becoming visible or hidden. It is very important that a wallpaper only use CPU while it is visible.
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onVisibilityChanged(boolean)"
	 */
	public void onLWPVisibilityChanged(boolean visible)
	{

	}

	/**
	 * Convenience for SurfaceHolder.Callback.surfaceChanged().
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onSurfaceChanged(android.view.SurfaceHolder,%20int,%20int,%20int)"
	 */
    public void onLWPSurfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {

    }

    /**
     * Convenience for SurfaceHolder.Callback.surfaceCreated().
     * 
     * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onSurfaceCreated(android.view.SurfaceHolder)"
     */
    public void onLWPSurfaceCreated(SurfaceHolder holder)
    {

    }

	/**
	 * Convenience for SurfaceHolder.Callback.surfaceDestroyed().
	 * 
	 * @see "http://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine.html#onSurfaceDestroyed(android.view.SurfaceHolder)"
	 */
    public void onLWPSurfaceDestroyed(SurfaceHolder holder)
    {
    	
    }
}
